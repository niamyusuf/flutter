# OVO App Flutter UI #
Education purpose only, content may have copyrighted content
* Logo
* Icon
* All Assets on res/images

Ok, ini hasil dari challenge pagi ini.
Masih belum terbiasa mengatur font dan warna agar sesuai dengan design,
jadi tidak 100%, tapi ok lah. Namanya juga latihan :-)

![alt text](https://i.imgur.com/vrloPLN.png)



